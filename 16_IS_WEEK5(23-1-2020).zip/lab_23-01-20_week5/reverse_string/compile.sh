gcc tcp_client.c -o client
gcc server.c -o server
