gcc udp_client.c -o client
gcc tcp_client.c -o tcp_client
gcc server.c -o server
