gcc UDP_Client.c -o client
gcc ./Ser/UDP_Ser.c -o server
