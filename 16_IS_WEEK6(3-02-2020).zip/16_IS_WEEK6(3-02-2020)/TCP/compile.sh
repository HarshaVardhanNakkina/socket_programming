gcc TCP_Client.c -o client
gcc ./Server/TCP_Ser.c -o server
