gcc dns.c -o dns
gcc client.c -o client
