gcc ssl-client.c -o client -lssl -lcrypto
gcc ssl-server.c -o server -lssl -lcrypto
